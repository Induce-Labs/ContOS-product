export class KickDto {}
